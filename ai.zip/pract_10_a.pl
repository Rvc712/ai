bowler(bumrah).
bowler(chalal).
batsman(sachin).
batsman(rohit).
batsman(virat).
batsman(dhoni).
criketer(X):-batsman(X);bowler(X).


