male(james1).
male(charles1).
male(charles2).
male(james2).
male(george1).
male(paul).
male(sam).

female(catherine).
female(elizabeth).
female(sophia).
female(claudia).
female(fay).

/*parent(child,parent). */
parent(charles1,james1).
parent(elizabeth,james1).
parent(charles2,charles1).
parent(catherine,charles1).
parent(james2,charles1).
parent(sophia,elizabeth).
parent(george1,sophia).
parent(george1,sam).
parent(catherine,fay).
parent(charles2,fay).
parent(james2,fay).
parent(sophia,paul).
parent(elizabeth,claudia).
parent(charles1,claudia).

/*rules*/
/*Dad is the father of child if he is male and is the child's parent*/
father(Child,Dad):-male(Dad),parent(Child,Dad).

/*mom is the mother of child if she is female and the child's parent*/
mother(Child,Mom):-female(Mom),parent(Child,Mom).

/*Bro is the brother of sibling if he is male and has the same parent as the sibling*/
brother(Sibling,Bro):-male(Bro),father(Sibling,Father),father(Bro,Father),Bro\=Sibling,mother(Sibling,Mother),mother(Bro,Mother).

/*Sis is ther sister of sibling if she is female and has the same parents as ther sibling*/
sister(Sibling,Sis):-female(sis),father(Sibling,Father),father(Sis,Father),Sis\=Sibling,mother(Sibling,Mother),mother(Sis,Mother).

/*Auntie is the aunt of kid if she is female and a sister of the kid's parent or she is female and married to the kid's uncle

This is the definition of an Aunt as given by dictionary.com:
1.The Sister of one's father or mother.
2. The wife of one's uncle.
*/
aunt(Kid,Auntie):-female(Auntie),parent(Kid,Parent),sister(Parent,Auntie).

/*aunt(Kid,Auntie):-female(Auntie),parent(Kid,Person),brother(Person,Brother),married(Auntie,Brother).*/
uncle(Kid,UncleBuck):-male(UncleBuck),parent(Kid,Parent),brother(Parent,UncleBuck).
/*uncle(Kid,UncleBuck):-male(UncleBuck),parent(Kid,Person),sister(Person,Sister),married(UncleBuck,Sister).*/



